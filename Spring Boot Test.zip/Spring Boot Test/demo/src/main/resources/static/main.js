$('#goBack').on('click', function ()
{
    $.ajax({
        type : 'POST',
        url : '/',
        success: function(data) {
            console.log('success',data);
        },
        error:function(exception){alert('Exeption:'+exception);}
    });
});