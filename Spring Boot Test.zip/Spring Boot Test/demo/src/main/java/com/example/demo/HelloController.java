package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController
{
    @RequestMapping("/")
    public String index()
    {
        return "index";
    }

    @RequestMapping("/secrets")
    public String getTheSecrets()
    {
        return "secrets";
    }

    @RequestMapping("/registration")
    public String getRegistration()
    {
        return "registration";
    }
}
